/***
 *
 * file to hold keys etc, for gdrive, Firebase and Stripe access. 
 * Held here to keep out of public repo, passed to BTWindow via messaging 
 *
 ***/

Keys = {
    CLIENT_ID : '986527980026-7oqfdk9270sseuru3hpmfk439s6o39h9.apps.googleusercontent.com',
    API_KEY : 'AIzaSyAS6QlSCfkZ_fv28RKlzH1gLMQkN7j1MzY',
    FB_KEY : 'AIzaSyAqtFRy33DJUVbrV9cbshLRLaGbUNp8eRw',
    STRIPE_KEY : 'pk_live_51J09w2JfoHixgzDGhUqGGQ4LhiZgz3cqBsj2zosjxWchZrxV3J3YkltzzYnWdSWDP1PlHdVLbWXPiEGsGwOukPiX00BzfARovq',
    
// live_key = 'pk_live_51J09w2JfoHixgzDGhUqGGQ4LhiZgz3cqBsj2zosjxWchZrxV3J3YkltzzYnWdSWDP1PlHdVLbWXPiEGsGwOukPiX00BzfARovq';
// test_key = 'pk_test_51J09w2JfoHixgzDGjawX0gVoce3QDjKIirPWvGcBHhLzaXkimCKkDrlgVefjeOul0SgDUkZvH6M56Liaa46y0WlP00bTJRDdwW'
};
