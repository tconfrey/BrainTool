
/* file to hold secret keys etc, for gdrive access. Held here to keep out of public repo, passed to BTWindow via messaging */
var config = {
    CLIENT_ID : '986527980026-7oqfdk9270sseuru3hpmfk439s6o39h9.apps.googleusercontent.com',
    API_KEY : 'AIzaSyAS6QlSCfkZ_fv28RKlzH1gLMQkN7j1MzY',
};
